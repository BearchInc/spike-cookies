import os
import flask
here = os.path.abspath(os.path.dirname(__file__))
app = flask.Flask(__name__)
